export interface FieldMapping {
  id: string
  kintoneFieldId: string
  serviceItemLabel: string
  serviceItemCode: string
  serviceItemType: string
  status: "mapped" | "unmapped" | "error"
  createdAt: string
}

export const fieldMappings: FieldMapping[] = [
  {
    id: "field-mapping-1",
    kintoneFieldId: "field-1",
    serviceItemLabel: "Company Name",
    serviceItemCode: "company_name",
    serviceItemType: "string",
    status: "mapped",
    createdAt: "2024-02-15T10:30:00Z",
  },
  {
    id: "field-mapping-2",
    kintoneFieldId: "field-2",
    serviceItemLabel: "Contact Person",
    serviceItemCode: "contact_person",
    serviceItemType: "string",
    status: "mapped",
    createdAt: "2024-02-15T10:35:00Z",
  },
  {
    id: "field-mapping-3",
    kintoneFieldId: "field-3",
    serviceItemLabel: "Email Address",
    serviceItemCode: "email_address",
    serviceItemType: "email",
    status: "mapped",
    createdAt: "2024-02-15T10:40:00Z",
  },
  {
    id: "field-mapping-4",
    kintoneFieldId: "field-6",
    serviceItemLabel: "Project Title",
    serviceItemCode: "project_title",
    serviceItemType: "string",
    status: "mapped",
    createdAt: "2024-02-20T15:00:00Z",
  },
]
