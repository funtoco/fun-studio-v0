export interface KintoneField {
  id: string
  appId: string
  label: string
  code: string
  type:
    | "SINGLE_LINE_TEXT"
    | "MULTI_LINE_TEXT"
    | "NUMBER"
    | "DATE"
    | "DATETIME"
    | "DROP_DOWN"
    | "CHECK_BOX"
    | "USER_SELECT"
  required: boolean
  description?: string
}

export const kintoneFields: KintoneField[] = [
  // 顧客管理アプリのフィールド
  {
    id: "field-1",
    appId: "app-1",
    label: "会社名",
    code: "company_name",
    type: "SINGLE_LINE_TEXT",
    required: true,
  },
  {
    id: "field-2",
    appId: "app-1",
    label: "担当者名",
    code: "contact_name",
    type: "SINGLE_LINE_TEXT",
    required: true,
  },
  {
    id: "field-3",
    appId: "app-1",
    label: "メールアドレス",
    code: "email",
    type: "SINGLE_LINE_TEXT",
    required: false,
  },
  {
    id: "field-4",
    appId: "app-1",
    label: "電話番号",
    code: "phone",
    type: "SINGLE_LINE_TEXT",
    required: false,
  },
  {
    id: "field-5",
    appId: "app-1",
    label: "業界",
    code: "industry",
    type: "DROP_DOWN",
    required: false,
  },
  // 案件管理アプリのフィールド
  {
    id: "field-6",
    appId: "app-2",
    label: "案件名",
    code: "project_name",
    type: "SINGLE_LINE_TEXT",
    required: true,
  },
  {
    id: "field-7",
    appId: "app-2",
    label: "顧客",
    code: "customer",
    type: "SINGLE_LINE_TEXT",
    required: true,
  },
  {
    id: "field-8",
    appId: "app-2",
    label: "開始日",
    code: "start_date",
    type: "DATE",
    required: true,
  },
  {
    id: "field-9",
    appId: "app-2",
    label: "終了予定日",
    code: "end_date",
    type: "DATE",
    required: false,
  },
  {
    id: "field-10",
    appId: "app-2",
    label: "ステータス",
    code: "status",
    type: "DROP_DOWN",
    required: true,
  },
]
