import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Info } from "lucide-react"

export function KintoneOAuthLegend() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center space-x-2">
          <Info className="h-4 w-4" />
          <span>OAuth 用語説明</span>
        </CardTitle>
        <CardDescription>Kintone OAuth 設定の基本用語</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <h4 className="text-sm font-medium mb-1">クライアント ID</h4>
            <p className="text-xs text-muted-foreground">OAuth アプリケーションを識別する一意の識別子</p>
          </div>

          <Separator />

          <div>
            <h4 className="text-sm font-medium mb-1">リダイレクト URI</h4>
            <p className="text-xs text-muted-foreground">認証後にユーザーがリダイレクトされる URL</p>
          </div>

          <Separator />

          <div>
            <h4 className="text-sm font-medium mb-1">スコープ</h4>
            <p className="text-xs text-muted-foreground mb-2">アプリケーションが要求するアクセス権限</p>
            <div className="flex flex-wrap gap-1">
              <Badge variant="outline" className="text-xs">
                k:app_record:read
              </Badge>
              <Badge variant="outline" className="text-xs">
                k:app_record:write
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
