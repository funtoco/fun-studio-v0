import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface DocLinkProps {
  title: string
  description?: string
  href?: string
  className?: string
}

export function DocLink({ title, description, href, className }: DocLinkProps) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost" className={`w-full justify-start h-auto p-3 text-left ${className}`} disabled>
            <div className="flex items-start justify-between w-full">
              <div className="flex-1">
                <p className="font-medium text-sm">{title}</p>
                {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
              </div>
              <ExternalLink className="h-3 w-3 text-muted-foreground ml-2 mt-0.5" />
            </div>
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>参照専用（現在は編集不可）</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
