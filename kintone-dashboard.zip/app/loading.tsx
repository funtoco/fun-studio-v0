import { DashboardSkeleton } from "@/components/loading-skeleton"

export default function Loading() {
  return <DashboardSkeleton />
}
