import { EmptyState } from "@/components/empty-state"
import { Button } from "@/components/ui/button"
import { FileQuestion, Home } from "lucide-react"
import Link from "next/link"

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <EmptyState
        icon={<FileQuestion className="h-16 w-16" />}
        title="ページが見つかりません"
        description="お探しのページは存在しないか、移動された可能性があります。"
        action={
          <Link href="/dashboard">
            <Button>
              <Home className="h-4 w-4 mr-2" />
              ダッシュボードに戻る
            </Button>
          </Link>
        }
      />
    </div>
  )
}
