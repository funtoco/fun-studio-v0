import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { StatusDot } from "@/components/status-dot"
import { connectors } from "@/data/connectors"
import { logs } from "@/data/logs"
import { Activity, Database, Settings, AlertCircle, CheckCircle, Clock } from "lucide-react"

export default function HomePage() {
  const activeConnectors = connectors.filter((c) => c.status === "active").length
  const totalApps = 15 // From our data
  const recentLogs = logs.slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Status Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">アクティブコネクタ</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeConnectors}</div>
            <p className="text-xs text-muted-foreground">全{connectors.length}コネクタ中</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">連携アプリ数</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalApps}</div>
            <p className="text-xs text-muted-foreground">Kintoneアプリ</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">今日の同期</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">成功: 22, エラー: 2</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">システム状態</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">正常</div>
            <p className="text-xs text-muted-foreground">全サービス稼働中</p>
          </CardContent>
        </Card>
      </div>

      {/* Connection Status */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>接続状況</CardTitle>
            <CardDescription>各コネクタの現在の状態</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {connectors.map((connector) => (
              <div key={connector.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <StatusDot status={connector.status} />
                  <div>
                    <p className="font-medium">{connector.name}</p>
                    <p className="text-sm text-muted-foreground">{connector.type}</p>
                  </div>
                </div>
                <Badge variant={connector.status === "active" ? "default" : "secondary"}>
                  {connector.status === "active"
                    ? "アクティブ"
                    : connector.status === "inactive"
                      ? "非アクティブ"
                      : "エラー"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>最近のアクティビティ</CardTitle>
            <CardDescription>システムの最新ログ</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentLogs.map((log) => (
              <div key={log.id} className="flex items-start space-x-3">
                <div className="mt-1">
                  {log.level === "error" ? (
                    <AlertCircle className="h-4 w-4 text-red-500" />
                  ) : log.level === "warning" ? (
                    <AlertCircle className="h-4 w-4 text-yellow-500" />
                  ) : (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium">{log.message}</p>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{new Date(log.timestamp).toLocaleString("ja-JP")}</span>
                    <Badge variant="outline" className="text-xs">
                      {log.source}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>開発ガイド</CardTitle>
          <CardDescription>Kintoneコネクタ開発のためのリソース</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <h4 className="font-medium">API リファレンス</h4>
              <p className="text-sm text-muted-foreground">Kintone REST APIの詳細な仕様書</p>
              <Button variant="outline" size="sm" disabled>
                ドキュメントを見る
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">サンプルコード</h4>
              <p className="text-sm text-muted-foreground">実装例とベストプラクティス</p>
              <Button variant="outline" size="sm" disabled>
                サンプルを見る
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">トラブルシューティング</h4>
              <p className="text-sm text-muted-foreground">よくある問題と解決方法</p>
              <Button variant="outline" size="sm" disabled>
                ガイドを見る
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
