あなたはSaaS管理画面に特化したUIデザイナーです。
以下要件で、**Kintone コネクターの管理ダッシュボード（参照専用UI）**のモックを作成してください。
コードは Next.js（App Router）＋ TypeScript、UI は shadcn/ui ＋ Tailwind。外部通信禁止、データは /data/*.ts の固定配列から読み込みます。

コンテキスト

目的: サービス管理者が「Kintone 接続の状態・設定・マッピング状況」を確認だけできるダッシュボードを提供する。編集や登録は将来の開発で行うため、今回は参照専用に限定。

連携方式: Kintone OAuth を利用。APIトークンは使わない想定。参考: cybozu OAuth クライアント追加手順（UI内にドキュメントリンク表現のダミーを配置）

ドキュメント例（参考表示のみ。クリックしても動作しないOK）: 「OAuth クライアント設定ガイド」

技術・UIフレーム

Next.js + TypeScript + App Router

UI: shadcn/ui + Tailwind

レイアウト: 左サイドバー / 上部ヘッダー / メインコンテンツ

参照専用: CRUD/編集フォーム/保存ボタンは生成しない（アイコンやボタンは「無効化・非表示」いずれかで表現）

データ: /data/*.ts の固定配列から読み込み（フェッチ・API不要）

ブランド: funtoco.jp トーン（落ち着いた実務系、過剰装飾なし）

テーマ: theme.ts に Color Token を定義し、全色指定は token 経由で行う

tokens: primary, secondary, accent, surface, border, text, muted, success, warning, danger

アクセシビリティ: WCAG AA 準拠（コントラスト、フォーカスリング、キーボード操作）

画面（すべて参照専用）

Dashboard（/dashboard）

カードでハイライト:

Kintone 接続ステータス（未接続 / 接続済 / エラー）

最終同期（ダミー表示でOK）

設定済みアプリ数、マッピング数

「開発ガイド」セクション（リンク風ダミー）に「Kintone OAuth クイックガイド」「OAuth クライアント追加手順」など

Connectors（/connectors）

一覧テーブル（shadcn Table）

列例: コネクター名（Kintone 固定でOK）/ ステータス（Badge）/ サブドメイン / OAuth クライアント名 / 作成日 / 更新日

行クリックで詳細へ

右上アクションは非表示または無効化（参照専用の明示）

Kintone Connector Detail（/connectors/kintone）

ヘッダー: コネクター名、状態Badge、最終更新日時

セクションA: OAuth 設定（参照のみ）

クライアントID（マスク表示OK）/ リダイレクトURI / スコープ / 認可状態

「OAuth クライアント追加手順を見る」（ドキュメントへのダミーリンク）

セクションB: 接続先情報

サブドメイン、環境（例: example）、エンドポイントの表示

セクションC: アプリ↔機能マッピング（一覧のみ）

テーブル列例: Kintoneアプリ名 / アプリコード / サービス機能名 / ステータス

セクションD: フィールドマッピング（一覧のみ）

テーブル列例: Kintoneフィールドラベル / フィールドコード / 型 / → / サービス項目ラベル / 項目コード / 型

セクションE: ログ/履歴（読み取りのみ）

最近のイベント: 認可成功、スコープ更新、マッピング更新などのダミー行

Kintone Apps（/kintone/apps）

アプリ一覧（カード or テーブル）

各行で「アプリ名 / アプリコード / フィールド数 / 最終更新」

クリックで詳細（/kintone/apps/[appCode]）へ

Kintone App Detail（/kintone/apps/[appCode]）

ヘッダー: アプリ名、アプリコード

タブ: 「フィールド」「関連マッピング」

フィールドタブ: テーブル（ラベル/コード/型/必須/備考）

関連マッピングタブ: このアプリに紐づく機能・フィールド対応を一覧表示

重要: どの画面にも「編集」「保存」「追加」などの操作UIは出さない。トグルや入力欄が必要なデザインの場合はDisabledで表現し、ツールチップで「参照専用（現在は編集不可）」と説明。

状態バリエーション

ステータス: 未接続 / 接続済 / エラー

ロード中（スケルトン）/ 空（Empty State）/ 非権限（ダミーのLock表示）

テーブルの「フィルタ無ヒット」表示

コンポーネント（shadcn/ui 前提）

AppShell（Left Sidebar / Top Header / Main）

PageHeader（タイトル、説明、右上にダミーのActions）

Card / Badge / Table / Tabs / Tooltip / Separator / Breadcrumb / ScrollArea

KeyValueList（ラベル:値の2カラム）

StatusDot（小さな状態アイコン）

DocLink（外部ドキュメントへのダミーリンク表示）

EmptyState（アイコン＋メッセージ＋補助文）

Legend（Kintone OAuth 用語の簡易凡例）

テーマとスタイル

theme.ts に CSS 変数ベースのトークン定義を生成

export const theme = {
  colors: {
    primary: 'var(--color-primary)',
    secondary: 'var(--color-secondary)',
    accent: 'var(--color-accent)',
    surface: 'var(--color-surface)',
    border: 'var(--color-border)',
    text: 'var(--color-text)',
    muted: 'var(--color-muted)',
    success: 'var(--color-success)',
    warning: 'var(--color-warning)',
    danger: 'var(--color-danger)',
  },
};


Tailwind の :root にライト/ダーク変数を用意

funtoco.jp の実務的トーンで、余白は8pxグリッド、角丸は控えめ、影は浅め

データ読み込み（固定配列）

/data/connectors.ts（Kintone のみ1件以上）

/data/kintoneApps.ts /data/kintoneFields.ts

/data/mappingsApps.ts（アプリ↔機能）

/data/mappingsFields.ts（フィールド対応）

/data/logs.ts（認可・状態遷移のダミー）

すべて型付き、id は文字列。参照専用でUIに反映

情報設計（抜粋）

ユーザーはまず Dashboard で状態を把握 → Connectors で詳細に降りる → Detail で OAuth/接続/マッピングを確認

用語ガイドとドキュメント導線を常に右カラム（またはフッター）に表示

受け入れ基準

すべてのページが参照専用であること（操作UIは無効化または非表示）

OAuth を前提にした「設定の項目・用語」がデザイン上で読み取れること

色指定はすべて theme.ts のトークン経由

コントラストとフォーカスリングが WCAG AA を満たすこと

データは /data/*.ts のみから読み込まれ、外部通信なしでモックが成立

必要なものは全部入れた。これをV0に投げれば、管理者向けの“読むだけKintoneコネクター”ダッシュボードの絵が出る。編集は将来の自分に丸投げでいい。今は見える化だ。
